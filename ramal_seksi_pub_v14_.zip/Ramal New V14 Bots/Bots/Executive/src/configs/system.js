module.exports = {


Protection: {
KufurEngel: true,
CapsEngel: true,
ReklamEngel: true,
SpamEngel: true,

}
}